package org.geotools.tutorial.snowflake;

import java.awt.RenderingHints.Key;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Map;
import java.util.Properties;

import org.geotools.api.data.DataStore;
import org.geotools.api.data.DataStoreFactorySpi;

public class SnowflakeDataStoreFactory implements DataStoreFactorySpi {
	
	public Connection con;

	/**
     * Public "no argument" constructor called by Factory Service Provider (SPI) entry listed in
     * META-INF/services/org.geotools.data.DataStoreFactorySPI
     */
	public SnowflakeDataStoreFactory() {}
	
	/** No implementation hints required at this time */
    public Map<Key, ?> getImplementationHints() {
        return Collections.emptyMap();
    }
    
    public String getDisplayName() {
        return "Snowflake";
    }

    public String getDescription() {
        return "Snowflake DataStore";
    }

    /** Confirm DataStore availability, null if unknown */
    Boolean isAvailable = null;

    /**
     * Test to see if this DataStore is available, for example if it has all the appropriate
     * libraries to construct an instance.
     *
     * <p>This method is used for interactive applications, so as to not advertise support for
     * formats that will not function.
     *
     * @return <tt>true</tt> if and only if this factory is available to create DataStores.
     */
    public synchronized boolean isAvailable() {
        if (isAvailable == null) {
            try {
                Class.forName("net.snowflake.client.jdbc.SnowflakeDriver", false, getClass().getClassLoader());
                isAvailable = true;
            } catch (ClassNotFoundException e) {
                isAvailable = false;
            }
        }
        return isAvailable;
    }
    
    /** Parameter description of information required to connect */
    public static final Param USER_PARAM = new Param("user",String.class,"Username",true,"");
    public static final Param PASSWORD_PARAM = new Param("password", String.class, "Password", true, "");
    public static final Param ACCOUNT_PARAM = new Param("account", String.class, "Account Identifier (Account.Region.CloudProvider)", true, "");
    public static final Param DB_PARAM = new Param("db", String.class, "Database to connect to", false, "");
    public static final Param SCHEMA_PARAM = new Param("schema", String.class, "Schema to connect to", false, "");
    
    public Param[] getParametersInfo() {
        return new Param[] {USER_PARAM,PASSWORD_PARAM, ACCOUNT_PARAM, DB_PARAM, SCHEMA_PARAM};
    }
    
    /**
     * Works for Snowflake Connection.
     *
     * @param params connection parameters
     * @return true for connection parameters indicating a csv file
     */
    public boolean canProcess(Map<String, ?> params) {
    	try {
            Class.forName("net.snowflake.client.jdbc.SnowflakeDriver");
        } catch (ClassNotFoundException ex) {
            System.err.println("Driver not found");
            return false;
        }
    	String user;
    	String password;
    	String account;
    	String accountID;
    	String db;
    	String schema;
    	
    	Properties properties = new Properties();
    	
        // build connection properties
    	try
    	{
	    	user = (String) USER_PARAM.lookUp(params);
	    	password = (String) PASSWORD_PARAM.lookUp(params);
	    	account = (String) ACCOUNT_PARAM.lookUp(params);
	    	db = (String) DB_PARAM.lookUp(params);
	    	schema = (String) SCHEMA_PARAM.lookUp(params);
	    	
	    	accountID = account.split(".")[0];
	    	
	        properties.put("user", user); // replace "" with your username
	        properties.put("password", password); // replace "" with your password
	        properties.put("account", accountID); // replace "" with your account name
	        properties.put("db", db); // replace "" with target database name
	        properties.put("schema", schema); // replace "" with target schema name
	        // properties.put("tracing", "on");
    	} catch (Exception e) {
    		return false;
    	}

        // create a new connection
        String connectStr = System.getenv("SF_JDBC_CONNECT_STRING");
        // use the default connection string if it is not set in environment
        if (connectStr == null) {
            connectStr = "jdbc:snowflake://" + account + ".snowflakecomputing.com"; // replace accountName with your account name
        }
        try
        {
        	con = DriverManager.getConnection(connectStr, properties);
        	return true;
        }
        catch (SQLException e)
        {
        	return false;
        }
    }
    
    public DataStore createDataStore(Map<String, ?> params) throws IOException {
    	String user = (String) USER_PARAM.lookUp(params);
    	String password = (String) PASSWORD_PARAM.lookUp(params);
    	String account = (String) ACCOUNT_PARAM.lookUp(params);
    	String db = (String) DB_PARAM.lookUp(params);
    	String schema = (String) SCHEMA_PARAM.lookUp(params);
    	
        return new SnowflakeDataStore(user, password, account, db, schema);
    }
    
    //private static final Logger LOGGER = Logging.getLogger("org.geotools.data.csv");
    public DataStore createNewDataStore(Map<String, ?> params) throws IOException {
    	String user = (String) USER_PARAM.lookUp(params);
    	String password = (String) PASSWORD_PARAM.lookUp(params);
    	String account = (String) ACCOUNT_PARAM.lookUp(params);
    	String db = (String) DB_PARAM.lookUp(params);
    	String schema = (String) SCHEMA_PARAM.lookUp(params);
        
    	//Do Logging stuff here
    	/*if (file.exists()) {
            LOGGER.warning("File already exsists: " + file);
        }*/
    	
        return new SnowflakeDataStore(user, password, account, db, schema);
    }
}
