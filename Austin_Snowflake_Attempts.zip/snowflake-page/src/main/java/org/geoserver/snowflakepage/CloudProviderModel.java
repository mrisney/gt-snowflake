package org.geoserver.snowflakepage;

import java.io.Serializable;

public class CloudProviderModel implements Serializable {

    public CloudProviderModel() {
        super();
    }

    private static final long serialVersionUID = 1L;

    private SelectOption cloudProvider;

    public SelectOption getCloudProvider() {
        return cloudProvider;
    }

    public void setCloudProvider(SelectOption cloudProvider) {
        this.cloudProvider = cloudProvider;
    }
}
