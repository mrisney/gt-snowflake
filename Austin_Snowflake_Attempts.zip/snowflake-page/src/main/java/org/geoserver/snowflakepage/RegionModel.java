package org.geoserver.snowflakepage;

import java.io.Serializable;

public class RegionModel implements Serializable {

    public RegionModel() {
        super();
    }

    private static final long serialVersionUID = 1L;

    private SelectOption region;

    public SelectOption getRegion() {
        return region;
    }

    public void setRegion(SelectOption region) {
        this.region = region;
    }
}
